    Frontend (React + Vite + Tailwind)

Run locally:
cd frontend
npm install
npm run dev

Build for production:
npm run build
")
