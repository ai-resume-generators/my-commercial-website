FastAPI backend for Niche Blog
- Run locally:
  python -m venv venv
  source venv/bin/activate   # or venv\Scripts\activate on Windows
  pip install -r requirements.txt
  uvicorn main:app --reload --port 8000
- Default admin: mirza-abdullah / change_me_password (change via env vars)
