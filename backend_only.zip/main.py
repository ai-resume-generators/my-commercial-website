from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from sqlmodel import SQLModel, Field, Session, create_engine, select
from datetime import datetime, timedelta
from typing import Optional
from passlib.context import CryptContext
from jose import JWTError, jwt
from pydantic import BaseModel
import os

SECRET_KEY = os.environ.get('SECRET_KEY', 'CHANGE_THIS_SECRET_KEY')
ALGORITHM = 'HS256'
ACCESS_TOKEN_EXPIRE_MINUTES = 60*24*7  # 7 days

DATABASE_URL = "sqlite:///./posts.db"
engine = create_engine(DATABASE_URL, echo=False)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class Post(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    body: str
    created_at: datetime = Field(default_factory=datetime.utcnow)

class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    username: str = Field(index=True, unique=True)
    hashed_password: str
    is_admin: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

class UserCreate(BaseModel):
    username: str
    password: str

app = FastAPI(title="Niche Blog API (Auth)")


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire, "sub": data.get("sub")})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def get_user(session: Session, username: str):
    return session.exec(select(User).where(User.username == username)).first()

def authenticate_user(session: Session, username: str, password: str):
    user = get_user(session, username)
    if not user:
        return False
    if not verify_password(password, user.hashed_password):
        return False
    return user

from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/token")

def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = TokenData(username=username)
    except JWTError:
        raise credentials_exception
    with Session(engine) as session:
        user = get_user(session, username=token_data.username)
        if user is None:
            raise credentials_exception
        return user

def get_current_active_user(current_user: User = Depends(get_current_user)):
    return current_user

def get_admin_user(current_user: User = Depends(get_current_user)):
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized as admin")
    return current_user

@app.on_event("startup")
def startup():
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        # Create an initial admin user if not exists
        admin_username = os.environ.get('INITIAL_ADMIN_USERNAME', 'mirza-abdullah')
        admin_password = os.environ.get('INITIAL_ADMIN_PASSWORD', 'change_me_password')
        existing = session.exec(select(User).where(User.username == admin_username)).first()
        if not existing:
            admin = User(username=admin_username, hashed_password=get_password_hash(admin_password), is_admin=True)
            session.add(admin)
        # Seed sample post if empty
        if not session.exec(select(Post)).all():
            session.add(Post(title="Welcome!", body="Your blog is ready."))
        session.commit()

@app.post('/token', response_model=Token)
def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    with Session(engine) as session:
        user = authenticate_user(session, form_data.username, form_data.password)
        if not user:
            raise HTTPException(status_code=400, detail="Incorrect username or password")
        access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        access_token = create_access_token(
            data={"sub": user.username}, expires_delta=access_token_expires
        )
        return {"access_token": access_token, "token_type": "bearer"}

@app.post('/users', status_code=201)
def create_user(user_in: UserCreate):
    with Session(engine) as session:
        existing = session.exec(select(User).where(User.username == user_in.username)).first()
        if existing:
            raise HTTPException(status_code=400, detail='Username already registered')
        user = User(username=user_in.username, hashed_password=get_password_hash(user_in.password), is_admin=False)
        session.add(user)
        session.commit()
        session.refresh(user)
        return {'username': user.username, 'id': user.id}

@app.get('/users/me')
def read_users_me(current_user: User = Depends(get_current_active_user)):
    return {'username': current_user.username, 'is_admin': current_user.is_admin, 'id': current_user.id}

@app.get('/admin/posts')
def admin_list_posts(admin_user: User = Depends(get_admin_user)):
    with Session(engine) as session:
        return session.exec(select(Post).order_by(Post.created_at.desc())).all()

@app.delete('/admin/posts/{post_id}')
def admin_delete_post(post_id: int, admin_user: User = Depends(get_admin_user)):
    with Session(engine) as session:
        post = session.get(Post, post_id)
        if not post:
            raise HTTPException(status_code=404, detail='Post not found')
        session.delete(post)
        session.commit()
        return {'status':'deleted'}

@app.post('/posts')
def create_post(post: Post, current_user: User = Depends(get_current_active_user)):
    with Session(engine) as session:
        new = Post(title=post.title, body=post.body)
        session.add(new)
        session.commit()
        session.refresh(new)
        return new

@app.get('/posts')
def list_posts():
    with Session(engine) as session:
        return session.exec(select(Post).order_by(Post.created_at.desc())).all()

@app.get('/')
def home():
    return {'message':'API running'}
