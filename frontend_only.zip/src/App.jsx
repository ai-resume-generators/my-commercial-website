import React, {useEffect, useState} from 'react'

export default function App(){
  const [posts, setPosts] = useState([])
  useEffect(()=>{ fetch('http://localhost:8000/posts').then(r=>r.json()).then(setPosts).catch(()=>{}) },[])
  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">Niche Blog</h1>
        {posts.map(p=> (
          <article key={p.id} className="bg-white p-4 mb-4 rounded shadow">
            <h2 className="font-semibold text-xl">{p.title}</h2>
            <p className="text-gray-700 mt-2">{p.body}</p>
          </article>
        ))}
      </div>
    </div>
  )
}
